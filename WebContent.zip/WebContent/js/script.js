var myModule = angular.module("ShoppingApp", ["ui.router", "ngCookies"]);

myModule.config(function($stateProvider, $urlRouterProvider) {
    
    $urlRouterProvider.otherwise('/home');
    
    $stateProvider

    // State home and multiple named views
    .state('home', {
        url: '/home',
        views: {

            // the main template will be placed here (relatively named)
            '': { templateUrl: 'partials/home.html' },

            // the child views will be defined here (absolutely named) viewname@statename
            'banner@home': { template: 'Home page banner goes here..' }
        }
    })
    
    // State viewcart
    .state('viewcart', {
        url: '/viewcart',
        templateUrl: 'partials/view-cart.html',
        controller: 'ProductsController'
    })
    
    // State about
    .state('about', {
        url: '/about',
        templateUrl: 'partials/about.html'
    }) 
    
    // State login
    .state('login', {
        url: '/login',
        templateUrl: 'partials/login.html',
        controller: 'LoginController',
        controllerAs: 'vm'
    })
    
    // State register
    .state('register', {
        url: '/register',
        templateUrl: 'partials/register.html',
        controller: 'RegisterController',
        controllerAs: 'vm'
    })    
    
    // State products
    .state('products', {
        abstract: true,
        url: '/products',
        templateUrl: 'partials/products.html',
        controller: 'ProductsController'
    })
    
    // State products.list
    .state('products.list', {
        url: '/list',
        templateUrl: 'partials/products-list.html'
    })
    
    // State products.detail
    .state('products.detail', {
        url: '/:id',
        templateUrl: 'partials/products-detail.html',
        controller: function($scope, $stateParams){
            $scope.product = $scope.products[$stateParams.id - 1];
        }
    })
});

myModule.controller("MainController", function($scope, $state, $stateParams, $window, AuthenticationService) {
	
	$scope.$state = $state;
	$scope.$stateParams = $stateParams;
	
	$scope.parseInt = parseInt;
	
	if($window.sessionStorage.getItem('cart') == undefined) {
		this.cart = [];
		$window.sessionStorage.setItem('cart', JSON.stringify(this.cart));
	}
	else {
		this.cart = JSON.parse($window.sessionStorage.getItem('cart'));
		
	}
	
	this.logout = function(){
		AuthenticationService.ClearCredentials();
	};
	
	this.isInCart = function(prodId) {
		
		var cart = JSON.parse($window.sessionStorage.getItem('cart'));
		
		for(i in cart) {
			
			if(cart[i].productId == prodId) {
				return i;
			}
		}
		
		return false;
	};
	
	this.addToCart = function(id) {
		
		if(!this.isInCart(id)) {
			var newItem = {};
			newItem.productId = id;
			newItem.qty = 1;
			
			this.cart.push(newItem);
			$window.sessionStorage.setItem('cart', JSON.stringify(this.cart));
		}
	};

	this.removeFromCart = function(index) {
		this.cart.splice(index, 1);
		$window.sessionStorage.setItem('cart', JSON.stringify(this.cart));
	};
	
	this.updateCart = function(index, item) {
		this.cart[index] = item;
		$window.sessionStorage.setItem('cart', JSON.stringify(this.cart));
	};
	
});

myModule.controller("ProductsController", function($scope, ProductService) {
	
    (function Init() {
        $scope.products = [];
        ProductService.getProducts()
        .then(
        	function(result) {
                //console.log(result);
        		$scope.products = result;
        	}, function(error) {
        	
        		console.log(error.statusText);
        	});                  

    })();        
    
    $scope.getProduct = function(id){
		// find and return an existing item with the given id
    	var products = $scope.products;
		for (i in products) {
			if(products[i].productId == id) {
				return products[i];
			}
		}
	};
	
    
});


myModule.service("OrderService", function($http) {

	this.orders = [];
	this.getOrders = function() {
		
		return this.orders;
	};

});

myModule.service("ProductService", function($http, $q) {
	
	var deferred = $q.defer();
	
	this.getProducts = function() {
		
		return $http.get('js/products.json')
			.then(function(response) {
				
				deferred.resolve(response.data);
				return deferred.promise;
				
			}, function(response) {
				
				deferred.reject(response);				
				return deferred.promise;
			});
	};
});


myModule.run(run);

run.$inject = ['$rootScope', '$location', '$cookieStore', '$http'];
function run($rootScope, $location, $cookieStore, $http) {
    // keep user logged in after page refresh
    $rootScope.globals = $cookieStore.get('globals') || {};
    if ($rootScope.globals.currentUser) {
        $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
    }

    $rootScope.$on('$locationChangeStart', function (event, next, current) {
        // redirect to login page if not logged in and trying to access a restricted page
        var restrictedPage = $.inArray($location.path(), ['/login', '/register']) === -1;
        var loggedIn = $rootScope.globals.currentUser;
        if (restrictedPage && !loggedIn) {
            $location.path('/login');
        }
    });
}